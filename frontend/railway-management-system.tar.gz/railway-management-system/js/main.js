/**
 * Main JavaScript Engine - Data Store Initializer & Utilities
 */

// Initialize LocalStorage Data Store
function initDataStore() {
  if (!localStorage.getItem('rms_initialized')) {
    // Seed Default Users
    const defaultUsers = [
      {
        id: 'USR-1001',
        name: 'Rahim Ahmed',
        email: 'user@railway.com',
        password: 'user123',
        phone: '01711223344',
        nid: '1994829102931',
        dob: '1994-05-12',
        gender: 'Male',
        address: '12 Dhanmondi, Dhaka',
        role: 'user',
        createdAt: '2026-01-15'
      },
      {
        id: 'USR-1002',
        name: 'System Admin',
        email: 'admin@railway.com',
        password: 'admin123',
        phone: '01899887766',
        nid: '1988123456789',
        dob: '1988-10-20',
        gender: 'Female',
        address: 'Railway HQ, Dhaka',
        role: 'admin',
        createdAt: '2025-12-01'
      },
      {
        id: 'USR-1003',
        name: 'Anisur Rahman',
        email: 'tm@railway.com',
        password: 'tm123',
        phone: '01755443322',
        nid: '1991234567890',
        dob: '1989-08-14',
        gender: 'Male',
        address: 'Kamalapur Railway HQ, Dhaka',
        role: 'ticket_manager',
        designation: 'Ticket Manager',
        station: 'Dhaka (Kamalapur)',
        createdAt: '2026-01-20'
      },
      {
        id: 'USR-1004',
        name: 'Kamal Hossain',
        email: 'sm@railway.com',
        password: 'sm123',
        phone: '01811223344',
        nid: '1985123456789',
        dob: '1985-04-10',
        gender: 'Male',
        address: 'Station Master Residence, Kamalapur',
        role: 'station_master',
        designation: 'Chief Station Master',
        station: 'Dhaka (Kamalapur)',
        createdAt: '2026-01-18'
      },
      {
        id: 'USR-1006',
        name: 'Tanvir Hossain',
        email: 'trainmanager@railway.com',
        password: 'train123',
        phone: '01722334455',
        nid: '1987654321098',
        dob: '1987-09-15',
        gender: 'Male',
        address: 'Railway Staff Quarter, Kamalapur',
        role: 'train_manager',
        designation: 'Train Manager',
        station: 'Dhaka (Kamalapur)',
        assignedTrainId: 'TR-701',
        assignedTrainName: 'Sonar Bangla Express',
        createdAt: '2026-01-22'
      },
      {
        id: 'USR-1005',
        name: 'Tariqul Islam',
        email: 'tariq@gmail.com',
        password: 'pass123',
        phone: '01912345678',
        nid: '1990456123789',
        dob: '1990-03-25',
        gender: 'Male',
        address: 'GEC Circle, Chittagong',
        role: 'user',
        createdAt: '2026-02-10'
      }
    ];

    // Seed Stations
    const defaultStations = [
      { id: 'ST-101', name: 'Dhaka (Kamalapur)', code: 'DKA', city: 'Dhaka', platforms: 11, status: 'Active' },
      { id: 'ST-102', name: 'Chattogram Junction', code: 'CTG', city: 'Chittagong', platforms: 8, status: 'Active' },
      { id: 'ST-103', name: 'Sylhet Station', code: 'SYL', city: 'Sylhet', platforms: 5, status: 'Active' },
      { id: 'ST-104', name: 'Rajshahi Station', code: 'RJH', city: 'Rajshahi', platforms: 6, status: 'Active' },
      { id: 'ST-105', name: 'Cox\'s Bazar Station', code: 'CXB', city: 'Cox\'s Bazar', platforms: 4, status: 'Active' },
      { id: 'ST-106', name: 'Khulna Station', code: 'KLN', city: 'Khulna', platforms: 5, status: 'Active' },
      { id: 'ST-107', name: 'Airport Station', code: 'APT', city: 'Dhaka', platforms: 4, status: 'Active' },
      { id: 'ST-108', name: 'Cumilla Station', code: 'CML', city: 'Cumilla', platforms: 3, status: 'Active' }
    ];

    // Seed Trains
    const defaultTrains = [
      {
        id: 'TR-701',
        name: 'Sonar Bangla Express',
        type: 'Intercity',
        source: 'Dhaka (Kamalapur)',
        destination: 'Chattogram Junction',
        deptTime: '07:00 AM',
        arrTime: '12:15 PM',
        duration: '5h 15m',
        fare: 650,
        availableSeats: 84,
        totalCoaches: 14,
        offDay: 'Saturday',
        status: 'Operational'
      },
      {
        id: 'TR-702',
        name: 'Suborno Express',
        type: 'Intercity',
        source: 'Chattogram Junction',
        destination: 'Dhaka (Kamalapur)',
        deptTime: '03:00 PM',
        arrTime: '08:20 PM',
        duration: '5h 20m',
        fare: 650,
        availableSeats: 62,
        totalCoaches: 14,
        offDay: 'Monday',
        status: 'Operational'
      },
      {
        id: 'TR-713',
        name: 'Cox\'s Bazar Express',
        type: 'Super Fast',
        source: 'Dhaka (Kamalapur)',
        destination: 'Cox\'s Bazar Station',
        deptTime: '06:30 AM',
        arrTime: '03:00 PM',
        duration: '8h 30m',
        fare: 950,
        availableSeats: 45,
        totalCoaches: 18,
        offDay: 'Tuesday',
        status: 'Operational'
      },
      {
        id: 'TR-717',
        name: 'Kalindi Express',
        type: 'Intercity',
        source: 'Dhaka (Kamalapur)',
        destination: 'Sylhet Station',
        deptTime: '06:40 AM',
        arrTime: '01:20 PM',
        duration: '6h 40m',
        fare: 520,
        availableSeats: 110,
        totalCoaches: 12,
        offDay: 'Wednesday',
        status: 'Operational'
      },
      {
        id: 'TR-755',
        name: 'Silkcity Express',
        type: 'Intercity',
        source: 'Dhaka (Kamalapur)',
        destination: 'Rajshahi Station',
        deptTime: '02:40 PM',
        arrTime: '08:30 PM',
        duration: '5h 50m',
        fare: 480,
        availableSeats: 92,
        totalCoaches: 12,
        offDay: 'Sunday',
        status: 'Operational'
      },
      {
        id: 'TR-725',
        name: 'Sundarban Express',
        type: 'Intercity',
        source: 'Dhaka (Kamalapur)',
        destination: 'Khulna Station',
        deptTime: '08:15 AM',
        arrTime: '04:00 PM',
        duration: '7h 45m',
        fare: 580,
        availableSeats: 70,
        totalCoaches: 12,
        offDay: 'Wednesday',
        status: 'Operational'
      }
    ];

    // Seed Coaches
    const defaultCoaches = [
      { id: 'CCH-01', trainId: 'TR-701', name: 'KA', type: 'AC Berth', seatsCount: 36, status: 'Active' },
      { id: 'CCH-02', trainId: 'TR-701', name: 'KHA', type: 'AC Seat / Snigdha', seatsCount: 60, status: 'Active' },
      { id: 'CCH-03', trainId: 'TR-701', name: 'GA', type: 'Shovon Chair', seatsCount: 70, status: 'Active' },
      { id: 'CCH-04', trainId: 'TR-713', name: 'A', type: 'AC Berth', seatsCount: 36, status: 'Active' },
      { id: 'CCH-05', trainId: 'TR-713', name: 'B', type: 'AC Seat / Snigdha', seatsCount: 60, status: 'Active' },
      { id: 'CCH-06', trainId: 'TR-713', name: 'C', type: 'Shovon Chair', seatsCount: 70, status: 'Active' }
    ];

    // Seed Bookings & Tickets
    const defaultBookings = [
      {
        id: 'BKG-88901',
        ticketId: 'TKT-99101',
        userId: 'USR-1001',
        passengerName: 'Rahim Ahmed',
        passengerPhone: '01711223344',
        trainId: 'TR-701',
        trainName: 'Sonar Bangla Express',
        source: 'Dhaka (Kamalapur)',
        destination: 'Chattogram Junction',
        journeyDate: '2026-08-10',
        coach: 'KA (AC Berth)',
        seats: ['KA-04', 'KA-05'],
        passengerType: 'Adult',
        totalFare: 1300,
        vat: 65,
        serviceCharge: 20,
        grandTotal: 1385,
        paymentMethod: 'bKash',
        paymentStatus: 'Paid',
        bookingStatus: 'Confirmed',
        createdAt: '2026-08-01 10:30 AM'
      },
      {
        id: 'BKG-88902',
        ticketId: 'TKT-99102',
        userId: 'USR-1001',
        passengerName: 'Rahim Ahmed',
        passengerPhone: '01711223344',
        trainId: 'TR-713',
        trainName: 'Cox\'s Bazar Express',
        source: 'Dhaka (Kamalapur)',
        destination: 'Cox\'s Bazar Station',
        journeyDate: '2026-08-15',
        coach: 'B (Snigdha)',
        seats: ['B-12'],
        passengerType: 'Adult',
        totalFare: 950,
        vat: 47,
        serviceCharge: 20,
        grandTotal: 1017,
        paymentMethod: 'Credit Card',
        paymentStatus: 'Paid',
        bookingStatus: 'Confirmed',
        createdAt: '2026-08-01 11:15 AM'
      }
    ];

    // Seed Complaints
    const defaultComplaints = [
      { id: 'CMP-501', userId: 'USR-1001', name: 'Rahim Ahmed', category: 'AC Non-Functional', train: 'Sonar Bangla Express', date: '2026-07-28', description: 'AC unit in KA coach was blowing warm air throughout the journey.', status: 'Pending' },
      { id: 'CMP-502', userId: 'USR-1003', name: 'Tariqul Islam', category: 'Cleanliness Issue', train: 'Suborno Express', date: '2026-07-20', description: 'Washroom in GHA coach lacked running water and hand soap.', status: 'Resolved' }
    ];

    // Seed Lost Items
    const defaultLostItems = [
      { id: 'LST-301', userId: 'USR-1001', item: 'Black Leather Backpack', train: 'Sonar Bangla Express', date: '2026-07-25', description: 'Left under seat KA-04. Contains HP laptop and notebook.', status: 'In Review' },
      { id: 'LST-302', userId: 'USR-1003', item: 'Reading Glasses Case', train: 'Cox\'s Bazar Express', date: '2026-07-29', description: 'Brown rayban glasses case on seat window ledge.', status: 'Found & Verified' }
    ];

    // Seed Cancellations & Refunds
    const defaultCancellations = [
      { id: 'CNC-101', ticketId: 'TKT-99080', userId: 'USR-1003', train: 'Kalindi Express', reason: 'Personal Emergency', refundAmount: 440, status: 'Approved', requestedAt: '2026-07-30' }
    ];

    const defaultRefunds = [
      { id: 'RFD-201', cancellationId: 'CNC-101', userId: 'USR-1003', amount: 440, status: 'Completed', processedAt: '2026-07-31' }
    ];

    // Seed Employees
    const defaultEmployees = [
      { id: 'EMP-001', name: 'Kamal Hossain', designation: 'Station Master', station: 'Dhaka (Kamalapur)', phone: '01700011233', status: 'Active' },
      { id: 'EMP-002', name: 'Mahmudul Hasan', designation: 'Locomotive Pilot', station: 'Chattogram Junction', phone: '01800022344', status: 'On Leave' },
      { id: 'EMP-003', name: 'Nasreen Akhter', designation: 'Ticket Examiner (TTE)', station: 'Dhaka (Kamalapur)', phone: '01900334455', status: 'Active' }
    ];

    // Seed Routes & Platforms & Seats
    const defaultRoutes = [
      { id: 'ROT-01', routeName: 'Dhaka - Chittagong Direct', source: 'Dhaka (Kamalapur)', destination: 'Chattogram Junction', distanceKm: 320, totalStations: 4, status: 'Active' },
      { id: 'ROT-02', routeName: 'Dhaka - Cox\'s Bazar Express Route', source: 'Dhaka (Kamalapur)', destination: 'Cox\'s Bazar Station', distanceKm: 460, totalStations: 5, status: 'Active' },
      { id: 'ROT-03', routeName: 'Dhaka - Sylhet Scenic Route', source: 'Dhaka (Kamalapur)', destination: 'Sylhet Station', distanceKm: 310, totalStations: 6, status: 'Active' }
    ];

    const defaultPlatforms = [
      { id: 'PLT-01', station: 'Dhaka (Kamalapur)', platformNumber: 1, type: 'Broad Gauge', status: 'Available' },
      { id: 'PLT-02', station: 'Dhaka (Kamalapur)', platformNumber: 2, type: 'Meter Gauge', status: 'Occupied' },
      { id: 'PLT-03', station: 'Chattogram Junction', platformNumber: 1, type: 'Broad Gauge', status: 'Available' }
    ];

    const defaultSeats = [
      { id: 'ST-01', trainId: 'TR-701', coach: 'KA', seatNumber: 'KA-01', classType: 'AC Berth', status: 'Available' },
      { id: 'ST-02', trainId: 'TR-701', coach: 'KA', seatNumber: 'KA-02', classType: 'AC Berth', status: 'Available' },
      { id: 'ST-03', trainId: 'TR-701', coach: 'KA', seatNumber: 'KA-04', classType: 'AC Berth', status: 'Booked' },
      { id: 'ST-04', trainId: 'TR-701', coach: 'KA', seatNumber: 'KA-05', classType: 'AC Berth', status: 'Booked' }
    ];

    // Seed Schedules
    const defaultSchedules = [
      {
        id: 'SCH-101',
        trainId: 'TR-701',
        trainName: 'Sonar Bangla Express',
        source: 'Dhaka (Kamalapur)',
        destination: 'Chattogram Junction',
        departureTime: '07:00 AM',
        arrivalTime: '12:15 PM',
        platform: 'Platform #1',
        routeInfo: 'Dhaka → Airport → Cumilla → Feni → Chattogram',
        offDay: 'Saturday',
        status: 'Operational'
      },
      {
        id: 'SCH-102',
        trainId: 'TR-702',
        trainName: 'Suborno Express',
        source: 'Chattogram Junction',
        destination: 'Dhaka (Kamalapur)',
        departureTime: '03:00 PM',
        arrivalTime: '08:20 PM',
        platform: 'Platform #2',
        routeInfo: 'Chattogram → Feni → Cumilla → Airport → Dhaka',
        offDay: 'Monday',
        status: 'Operational'
      },
      {
        id: 'SCH-103',
        trainId: 'TR-713',
        trainName: 'Cox\'s Bazar Express',
        source: 'Dhaka (Kamalapur)',
        destination: 'Cox\'s Bazar Station',
        departureTime: '06:30 AM',
        arrivalTime: '03:00 PM',
        platform: 'Platform #3',
        routeInfo: 'Dhaka → Airport → Chattogram → Dohazari → Cox\'s Bazar',
        offDay: 'Tuesday',
        status: 'Operational'
      },
      {
        id: 'SCH-104',
        trainId: 'TR-717',
        trainName: 'Kalindi Express',
        source: 'Dhaka (Kamalapur)',
        destination: 'Sylhet Station',
        departureTime: '06:40 AM',
        arrivalTime: '01:20 PM',
        platform: 'Platform #4',
        routeInfo: 'Dhaka → Bhairab Bazar → Brahmanbaria → Sreemangal → Sylhet',
        offDay: 'Wednesday',
        status: 'Operational'
      },
      {
        id: 'SCH-105',
        trainId: 'TR-755',
        trainName: 'Silkcity Express',
        source: 'Dhaka (Kamalapur)',
        destination: 'Rajshahi Station',
        departureTime: '02:40 PM',
        arrivalTime: '08:30 PM',
        platform: 'Platform #5',
        routeInfo: 'Dhaka → Joydebpur → Tangail → Ishwardi Bypass → Rajshahi',
        offDay: 'Sunday',
        status: 'Operational'
      }
    ];

    const defaultMaintenance = [
      { id: 'MNT-401', trainId: 'TR-701', trainName: 'Sonar Bangla Express', category: 'AC / Cooling System', target: 'Coach KA', severity: 'Medium', desc: 'AC cooling thermostat calibrated at Kamalapur depot.', inspector: 'Tanvir Hossain', status: 'Under Repair', date: '2026-08-28' },
      { id: 'MNT-402', trainId: 'TR-701', trainName: 'Sonar Bangla Express', category: 'Brake Check', target: 'Locomotive Engine #3204', severity: 'Low', desc: 'Routine pneumatic pressure certified by Loco foreman.', inspector: 'Kamal Hossain', status: 'Resolved', date: '2026-08-27' },
      { id: 'MNT-403', trainId: 'TR-713', trainName: 'Cox\'s Bazar Express', category: 'Coupler & Suspension', target: 'Coach B', severity: 'High', desc: 'Suspension spring inspection completed before long run.', inspector: 'Mahmudul Hasan', status: 'Reported', date: '2026-08-28' }
    ];

    localStorage.setItem('users', JSON.stringify(defaultUsers));
    localStorage.setItem('stations', JSON.stringify(defaultStations));
    localStorage.setItem('trains', JSON.stringify(defaultTrains));
    localStorage.setItem('coaches', JSON.stringify(defaultCoaches));
    localStorage.setItem('bookings', JSON.stringify(defaultBookings));
    localStorage.setItem('tickets', JSON.stringify(defaultBookings)); // tickets mirror confirmed bookings
    localStorage.setItem('complaints', JSON.stringify(defaultComplaints));
    localStorage.setItem('lostItems', JSON.stringify(defaultLostItems));
    localStorage.setItem('cancellations', JSON.stringify(defaultCancellations));
    localStorage.setItem('refunds', JSON.stringify(defaultRefunds));
    localStorage.setItem('employees', JSON.stringify(defaultEmployees));
    localStorage.setItem('routes', JSON.stringify(defaultRoutes));
    localStorage.setItem('platforms', JSON.stringify(defaultPlatforms));
    localStorage.setItem('seats', JSON.stringify(defaultSeats));
    localStorage.setItem('schedules', JSON.stringify(defaultSchedules));
    localStorage.setItem('maintenanceLogs', JSON.stringify(defaultMaintenance));

    const defaultScheduleRequests = [
      {
        id: 'SRQ-501',
        trainId: 'TR-701',
        train: 'Sonar Bangla Express',
        currentSchedule: 'Dept: 07:00 AM | Arr: 12:15 PM | Platform: Platform #1',
        requestedChange: 'Shift departure to 07:20 AM and assign Platform #2',
        reason: 'Locomotive maintenance clearance and morning track congestion near Airport station',
        status: 'Pending',
        requestedBy: 'Tanvir Hossain (Train Manager)',
        createdAt: 'Today, 08:30 AM'
      },
      {
        id: 'SRQ-502',
        trainId: 'TR-702',
        train: 'Suborno Express',
        currentSchedule: 'Dept: 03:00 PM | Arr: 08:30 PM | Platform: Platform #2',
        requestedChange: 'Add temporary stoppage at Cumilla Junction (10 mins)',
        reason: 'Passenger connectivity request during peak weekend rush',
        status: 'Approved',
        requestedBy: 'Train Operations Division',
        createdAt: 'Yesterday, 04:15 PM'
      },
      {
        id: 'SRQ-503',
        trainId: 'TR-713',
        train: "Cox's Bazar Express",
        currentSchedule: 'Dept: 10:30 PM | Arr: 07:20 AM | Platform: Platform #3',
        requestedChange: 'Early departure at 09:45 PM',
        reason: 'Single line crossing optimization',
        status: 'Rejected',
        requestedBy: 'Train Manager',
        createdAt: '2 days ago'
      }
    ];
    localStorage.setItem('schedule_update_requests', JSON.stringify(defaultScheduleRequests));

    localStorage.setItem('rms_initialized', 'true');
  }

  // Ensure schedule_update_requests exists
  if (!localStorage.getItem('schedule_update_requests')) {
    const defaultScheduleRequests = [
      {
        id: 'SRQ-501',
        trainId: 'TR-701',
        train: 'Sonar Bangla Express',
        currentSchedule: 'Dept: 07:00 AM | Arr: 12:15 PM | Platform: Platform #1',
        requestedChange: 'Shift departure to 07:20 AM and assign Platform #2',
        reason: 'Locomotive maintenance clearance and morning track congestion near Airport station',
        status: 'Pending',
        requestedBy: 'Tanvir Hossain (Train Manager)',
        createdAt: 'Today, 08:30 AM'
      },
      {
        id: 'SRQ-502',
        trainId: 'TR-702',
        train: 'Suborno Express',
        currentSchedule: 'Dept: 03:00 PM | Arr: 08:30 PM | Platform: Platform #2',
        requestedChange: 'Add temporary stoppage at Cumilla Junction (10 mins)',
        reason: 'Passenger connectivity request during peak weekend rush',
        status: 'Approved',
        requestedBy: 'Train Operations Division',
        createdAt: 'Yesterday, 04:15 PM'
      },
      {
        id: 'SRQ-503',
        trainId: 'TR-713',
        train: "Cox's Bazar Express",
        currentSchedule: 'Dept: 10:30 PM | Arr: 07:20 AM | Platform: Platform #3',
        requestedChange: 'Early departure at 09:45 PM',
        reason: 'Single line crossing optimization',
        status: 'Rejected',
        requestedBy: 'Train Manager',
        createdAt: '2 days ago'
      }
    ];
    localStorage.setItem('schedule_update_requests', JSON.stringify(defaultScheduleRequests));
  }
}

// Call store initializer
initDataStore();

// Guarantee default role accounts exist
(function ensureRoleAccounts() {
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  const requiredAccounts = [
    { id: 'USR-1001', name: 'Rahim Ahmed', email: 'user@railway.com', password: 'user123', role: 'user', phone: '01711223344' },
    { id: 'USR-1002', name: 'System Admin', email: 'admin@railway.com', password: 'admin123', role: 'admin', phone: '01899887766' },
    { id: 'USR-1003', name: 'Anisur Rahman', email: 'tm@railway.com', password: 'tm123', role: 'ticket_manager', phone: '01755443322', designation: 'Ticket Manager', station: 'Dhaka (Kamalapur)' },
    { id: 'USR-1004', name: 'Kamal Hossain', email: 'sm@railway.com', password: 'sm123', role: 'station_master', phone: '01811223344', designation: 'Station Master', station: 'Dhaka (Kamalapur)' },
    { id: 'USR-1006', name: 'Tanvir Hossain', email: 'trainmanager@railway.com', password: 'train123', role: 'train_manager', phone: '01722334455', designation: 'Train Manager', station: 'Dhaka (Kamalapur)', assignedTrainId: 'TR-701', assignedTrainName: 'Sonar Bangla Express' }
  ];

  let modified = false;
  requiredAccounts.forEach(acc => {
    if (!users.some(u => u.email.toLowerCase() === acc.email.toLowerCase())) {
      users.push(acc);
      modified = true;
    }
  });

  if (modified) {
    localStorage.setItem('users', JSON.stringify(users));
  }

  // Ensure default staff directory records are clean and standardized
  try {
    let employees = JSON.parse(localStorage.getItem('employees') || '[]');
    if (!employees || employees.length === 0) {
      employees = [
        { id: 'EMP-001', name: 'Kamal Hossain', designation: 'Station Master', station: 'Dhaka (Kamalapur)', phone: '01700011233', status: 'Active' },
        { id: 'EMP-002', name: 'Mahmudul Hasan', designation: 'Locomotive Pilot', station: 'Chattogram Junction', phone: '01800022344', status: 'On Leave' },
        { id: 'EMP-003', name: 'Nasreen Akhter', designation: 'Ticket Examiner (TTE)', station: 'Dhaka (Kamalapur)', phone: '01900334455', status: 'Active' }
      ];
      localStorage.setItem('employees', JSON.stringify(employees));
    } else {
      let empModified = false;
      employees.forEach(emp => {
        if (!emp.status || emp.status === 'undefined') {
          emp.status = 'Active';
          empModified = true;
        }
      });
      if (empModified) {
        localStorage.setItem('employees', JSON.stringify(employees));
      }
    }
  } catch (e) {
    console.error('Employee store sync error', e);
  }
})();

// User Session Management
function getCurrentUser() {
  const userJson = localStorage.getItem('currentUser');
  return userJson ? JSON.parse(userJson) : null;
}

function setCurrentUser(user) {
  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
  } else {
    localStorage.removeItem('currentUser');
  }
}

function logoutUser() {
  localStorage.removeItem('currentUser');
  showToast('Logged out successfully', 'info');
  setTimeout(() => {
    window.location.href = 'index.html';
  }, 600);
}

// Toast Notifications
function showToast(message, type = 'info') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3500);
}

// Format Currency
function formatBDT(amount) {
  return `৳${Number(amount).toLocaleString('en-IN')}`;
}

// Setup Global Navbar State
function updateNavbar() {
  const user = getCurrentUser();
  const navActions = document.getElementById('navActions');
  if (!navActions) return;

  if (user) {
    let roleLabel = 'Passenger';
    let portalLink = 'user-dashboard.html';
    let portalBtnText = 'My Portal';

    if (user.role === 'admin') {
      roleLabel = 'Admin';
      portalLink = 'admin-dashboard.html';
      portalBtnText = 'Admin Portal';
    } else if (user.role === 'ticket_manager') {
      roleLabel = 'Ticket Manager';
      portalLink = 'manage-tickets.html';
      portalBtnText = 'Tickets Portal';
    } else if (user.role === 'station_master') {
      roleLabel = 'Station Master';
      portalLink = 'manage-stations.html';
      portalBtnText = 'Station Portal';
    } else if (user.role === 'train_manager') {
      roleLabel = 'Train Manager';
      portalLink = 'train-manager-dashboard.html';
      portalBtnText = 'Train Portal';
    }

    navActions.innerHTML = `
      <div style="display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap;">
        <span style="color: #cbd5e1; font-size: 0.875rem;">
          Hi, <strong>${user.name.split(' ')[0]}</strong>
          <span class="inline-block ml-1 px-2 py-0.5 text-xs font-bold rounded bg-sky-500/20 text-sky-300 border border-sky-400/30">${roleLabel}</span>
        </span>
        <a href="${portalLink}" class="btn btn-sm btn-outline" style="color: #ffffff; border-color: #38bdf8;">${portalBtnText}</a>
        <button onclick="logoutUser()" class="btn btn-sm btn-danger">Logout</button>
      </div>
    `;
  } else {
    navActions.innerHTML = `
      <div style="display: flex; align-items: center; gap: 0.5rem;">
        <a href="login.html" class="btn btn-sm btn-outline" style="color: #ffffff; border-color: #38bdf8;">Login</a>
        <a href="register.html" class="btn btn-sm btn-primary">Register</a>
      </div>
    `;
  }

  // Set active nav link & clean up restricted navbar items
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => {
    if (link.getAttribute('href') === currentPath) {
      link.classList.add('active');
    }
    // Remove Lost Item from navbar for non-Station Masters
    if (link.getAttribute('href') === 'lost-item.html' || link.getAttribute('href') === 'manage-lost-items.html') {
      if (!user || user.role !== 'station_master') {
        link.parentElement?.remove();
      }
    }
  });
}

// Render Dynamic Role-Based Sidebar with Sticky Logout
function renderRoleSidebar() {
  const sidebarEl = document.querySelector('aside.sidebar');
  if (!sidebarEl) return;

  const user = getCurrentUser();
  if (!user) return;

  const currentPath = window.location.pathname.split('/').pop() || 'index.html';

  let roleHeader = 'Portal Navigation';
  let navItems = [];

  if (user.role === 'admin') {
    roleHeader = 'System Admin HQ';
    navItems = [
      { label: '📊 Main Dashboard', href: 'admin-dashboard.html' },
      { label: '👤 Profile', href: 'profile.html' },
      { label: '👔 Employee Management', href: 'manage-employees.html' },
      { label: '🚆 Train Fleet', href: 'manage-trains.html' },
      { label: '📅 Train Schedules', href: 'manage-schedules.html' },
      { label: '🚉 Station Management', href: 'manage-stations.html' },
      { label: '🛤️ Platform Management', href: 'manage-platforms.html' },
      { label: '🗺️ Route Management', href: 'manage-routes.html' },
      { label: '🎫 Ticket Management', href: 'manage-tickets.html' },
      { label: '❌ Cancellation Management', href: 'manage-cancellations.html' },
      { label: '💬 Complaints Management', href: 'manage-complaints.html' },
      { label: '🧳 Lost Item Management', href: 'manage-lost-items.html' },
      { label: '📑 All Bookings', href: 'manage-bookings.html' },
      { label: '💳 Payment Records', href: 'manage-payments.html' }
    ];
  } else if (user.role === 'ticket_manager') {
    roleHeader = 'Ticket Manager Portal';
    navItems = [
      { label: '📊 Dashboard', href: 'manage-tickets.html' },
      { label: '👤 Profile', href: 'profile.html' },
      { label: '🎫 Ticket Management', href: 'manage-tickets.html' },
      { label: '📑 Booking Management', href: 'manage-bookings.html' },
      { label: '📊 Reports & Cancellations', href: 'manage-cancellations.html' }
    ];
  } else if (user.role === 'station_master') {
    roleHeader = 'Station Master Portal';
    navItems = [
      { label: '📊 Operations Dashboard', href: 'manage-stations.html' },
      { label: '👤 Profile', href: 'profile.html' },
      { label: '🚉 Station Management', href: 'manage-stations.html' },
      { label: '🛤️ Platform Management', href: 'manage-platforms.html' },
      { label: '🗺️ Route Management', href: 'manage-routes.html' },
      { label: '📅 Train Schedule Management', href: 'manage-schedules.html' },
      { label: '🧳 Lost Item Management', href: 'manage-lost-items.html' },
      { label: '🔔 Notifications', href: 'javascript:void(0)', onclick: 'showNotificationsModal()' }
    ];
  } else if (user.role === 'train_manager') {
    roleHeader = 'Train Manager Portal';
    navItems = [
      { label: '📊 Operations Dashboard', href: 'train-manager-dashboard.html' },
      { label: '👤 Profile', href: 'profile.html' },
      { label: '📅 Train Schedules', href: 'manage-schedules.html' },
      { label: '🚆 Train Fleet Details', href: 'manage-trains.html' },
      { label: '🚃 Coaches Management', href: 'manage-coaches.html' },
      { label: '🚉 Platform Operations', href: 'manage-platforms.html' },
      { label: '🔔 Notifications', href: 'javascript:void(0)', onclick: 'showNotificationsModal()' }
    ];
  } else {
    // Passenger / User
    roleHeader = 'Passenger Portal';
    navItems = [
      { label: '📊 Dashboard', href: 'user-dashboard.html' },
      { label: '👤 Profile', href: 'profile.html' },
      { label: '🔍 Search/Book Ticket', href: 'search-train.html' },
      { label: '🎟️ My Tickets', href: 'my-tickets.html' },
      { label: '❌ Cancel Ticket', href: 'cancellation.html' },
      { label: '💵 Refund Status', href: 'refund.html' },
      { label: '💬 Complaints', href: 'complaint.html' },
      { label: '🔔 Notifications', href: 'javascript:void(0)', onclick: 'showNotificationsModal()' }
    ];
  }

  const linksHtml = navItems.map(item => {
    const isActive = (currentPath === item.href) ? 'active' : '';
    const onclickAttr = item.onclick ? `onclick="${item.onclick}"` : '';
    return `<a href="${item.href}" ${onclickAttr} class="sidebar-link ${isActive}"><span>${item.label}</span></a>`;
  }).join('');

  sidebarEl.innerHTML = `
    <div class="sidebar-header flex items-center justify-between">
      <span>${roleHeader}</span>
      <button onclick="toggleMobileSidebar()" class="md:hidden text-slate-400 hover:text-white text-lg font-bold p-1 cursor-pointer" aria-label="Close Sidebar">✕</button>
    </div>
    <nav class="sidebar-nav">
      ${linksHtml}
    </nav>
  `;

  // Attach click listener on mobile to close drawer
  sidebarEl.querySelectorAll('.sidebar-link').forEach(link => {
    link.addEventListener('click', () => {
      if (window.innerWidth <= 768) {
        sidebarEl.classList.remove('active');
        const backdrop = document.getElementById('sidebarDrawerBackdrop');
        if (backdrop) backdrop.remove();
      }
    });
  });
}

// Global Toggle Mobile Sidebar Drawer
window.toggleMobileSidebar = function() {
  const sidebar = document.querySelector('aside.sidebar');
  if (!sidebar) return;
  sidebar.classList.toggle('active');
  let backdrop = document.getElementById('sidebarDrawerBackdrop');
  if (sidebar.classList.contains('active')) {
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'sidebarDrawerBackdrop';
      backdrop.className = 'fixed inset-0 bg-slate-950/70 z-40 md:hidden transition-opacity cursor-pointer';
      backdrop.onclick = () => {
        sidebar.classList.remove('active');
        backdrop.remove();
      };
      document.body.appendChild(backdrop);
    }
  } else if (backdrop) {
    backdrop.remove();
  }
};

// Global System Notifications Modal
function showNotificationsModal() {
  let modal = document.getElementById('notificationsModalOverlay');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'notificationsModalOverlay';
    modal.className = 'modal-overlay active';
    modal.innerHTML = `
      <div class="modal-container max-w-md bg-slate-800 text-white border border-slate-700 rounded-2xl p-6 shadow-2xl">
        <div class="flex justify-between items-center pb-3 border-b border-slate-700 mb-4">
          <h3 class="text-lg font-bold text-white flex items-center gap-2"><span>🔔</span> System Notifications</h3>
          <button onclick="document.getElementById('notificationsModalOverlay').remove()" class="text-slate-400 hover:text-white text-xl font-bold cursor-pointer">&times;</button>
        </div>
        <div class="space-y-3 max-h-80 overflow-y-auto pr-1">
          <div class="p-3 bg-slate-900/80 rounded-xl border border-sky-500/30 text-xs">
            <div class="font-bold text-sky-400 mb-1">🚆 Train Schedule Update</div>
            <p class="text-slate-300">Sonar Bangla Express departure platform updated to Platform #1 at Kamalapur HQ.</p>
            <span class="text-[10px] text-slate-500 mt-1 block">10 mins ago</span>
          </div>
          <div class="p-3 bg-slate-900/80 rounded-xl border border-emerald-500/30 text-xs">
            <div class="font-bold text-emerald-400 mb-1">🎟️ Booking Confirmation</div>
            <p class="text-slate-300">Your recent seat reservation was verified by Railway E-Ticket server.</p>
            <span class="text-[10px] text-slate-500 mt-1 block">1 hour ago</span>
          </div>
          <div class="p-3 bg-slate-900/80 rounded-xl border border-amber-500/30 text-xs">
            <div class="font-bold text-amber-400 mb-1">⚠️ Advisory Notice</div>
            <p class="text-slate-300">Monsoon speed limits active on Eastern Zone tracks. Expect 15-min safety buffer.</p>
            <span class="text-[10px] text-slate-500 mt-1 block">Yesterday</span>
          </div>
        </div>
        <div class="mt-4 pt-3 border-t border-slate-700 flex justify-end">
          <button onclick="document.getElementById('notificationsModalOverlay').remove()" class="py-2 px-4 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-xl transition-all cursor-pointer">
            Close Notifications
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  } else {
    modal.classList.add('active');
  }
}

// Strict Role-Based Access Protection Guard
function enforcePageRolePermissions() {
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';

  // Public pages accessible without login
  const publicPages = ['index.html', 'login.html', 'register.html', 'search-train.html', 'train-results.html', 'train-details.html'];
  if (publicPages.includes(currentPath)) {
    return;
  }

  const currentUser = getCurrentUser();
  if (!currentUser) {
    showToast('Please sign in to access portal features.', 'danger');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 500);
    return;
  }

  const role = currentUser.role;

  // Rule 1: Employee Management ONLY Admin
  if (currentPath === 'manage-employees.html' && role !== 'admin') {
    showToast('Access Denied: Employee Management is restricted to System Admin.', 'danger');
    redirectToDefaultPortal(role);
    return;
  }

  // Rule 2: Admin-only portals
  const adminOnlyPages = ['admin-dashboard.html'];
  if (adminOnlyPages.includes(currentPath) && role !== 'admin') {
    showToast('Access Denied: System Admin privileges required.', 'danger');
    redirectToDefaultPortal(role);
    return;
  }

  // Rule 3: Lost Item Management accessible to Station Master and Admin
  const stationMasterAndAdminPages = ['manage-lost-items.html', 'lost-item.html'];
  if (stationMasterAndAdminPages.includes(currentPath) && role !== 'station_master' && role !== 'admin') {
    showToast('Access Denied: Lost Item Management is restricted to Station Staff & Admin.', 'danger');
    redirectToDefaultPortal(role);
    return;
  }

  // Rule 4: Payment Management accessible only to Admin and Ticket Manager
  if (currentPath === 'manage-payments.html' && !['admin', 'ticket_manager'].includes(role)) {
    showToast('Access Denied: Payment Management is restricted to Ticket Staff and Admin.', 'danger');
    redirectToDefaultPortal(role);
    return;
  }

  // Rule 4: Train Schedule Management accessible to Station Master, Train Manager, Admin
  if (currentPath === 'manage-schedules.html' && !['station_master', 'train_manager', 'admin'].includes(role)) {
    showToast('Access Denied: Schedule Management is restricted to Station Master, Train Manager, and Admin.', 'danger');
    redirectToDefaultPortal(role);
    return;
  }

  // Rule 5: Maintenance Management accessible to Admin, Train Manager, Station Master
  if (currentPath === 'manage-maintenance.html' && !['admin', 'train_manager', 'station_master'].includes(role)) {
    showToast('Access Denied: Maintenance Management is restricted to Operations Staff.', 'danger');
    redirectToDefaultPortal(role);
    return;
  }

  // Rule 5: Train Manager Portal ONLY Train Manager & Admin
  if (currentPath === 'train-manager-dashboard.html' && role !== 'train_manager' && role !== 'admin') {
    showToast('Access Denied: Train Manager Portal is restricted to Train Managers.', 'danger');
    redirectToDefaultPortal(role);
    return;
  }

  // Rule 5: Passenger Portal pages redirect if staff
  if (currentPath === 'user-dashboard.html' && role !== 'user' && role !== 'passenger') {
    redirectToDefaultPortal(role);
    return;
  }
}

function redirectToDefaultPortal(role) {
  let target = 'user-dashboard.html';
  if (role === 'admin') target = 'admin-dashboard.html';
  else if (role === 'ticket_manager') target = 'manage-tickets.html';
  else if (role === 'station_master') target = 'manage-stations.html';
  else if (role === 'train_manager') target = 'train-manager-dashboard.html';

  setTimeout(() => {
    window.location.href = target;
  }, 600);
}

document.addEventListener('DOMContentLoaded', () => {
  enforcePageRolePermissions();
  updateNavbar();
  renderRoleSidebar();

  // Mobile nav toggle
  const toggleBtn = document.getElementById('mobileNavToggle');
  const navMenu = document.getElementById('navMenu');
  if (toggleBtn && navMenu) {
    toggleBtn.addEventListener('click', () => {
      navMenu.classList.toggle('active');
    });
  }
});
